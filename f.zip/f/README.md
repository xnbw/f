## Alf Bot
BOT WHATSAPP YANG BISA DIGUNAKAN DI TERMUX


<img src = "https://i.ibb.co/jD65tdm/62-812-1347-7896-20201109-230938.jpg" width="320">




## CARA INSTALL
# TERMUX
```bash
> download termux
> buka
> pkg install git
> pkg install ffmpeg
> pkg install nodejs
> apt update && apt upgrade
> git clone https://github.com/alfiansx/alfbot
> cd alfbot
> bash install.sh
> npm i node-tesseract-ocr
> pkg install tesseract
> npm i
> node index.js
```


# FITUR

| KEADAAN       |               FITUR     |
| :-----------: | :--------------------------------:  |
|       ✅       |    PANTUN                         |
|       ✅       | ANIMEPICT                         |
|       ✅       | STICKER                           |
|       ✅       | NULIS 
|       ✅       | OCR                               |
|       ✅       | QUOTES                            |
|       ✅       | RANDOM PICT                       |
|       ✅       | ANIMEPICT                         |
|       ✅       | LIRIK                             |
|       ✅       | ALAY                              |
|       ✅       | YT,YTMP3,TWT,TIK TOK DOWNLOADER   |
|       ✅       | WIKIPEDIA                         |
|       ✅       | ARTI NAMA                         |
|       ✅       | SHOLAT                            |
|       ✅       | QURAN                             |

✅ aktif




## THANKS TO
* [`termux-whatsapp-bot`](https://github.com/fdciabdul/termux-whatsapp-bot)
* [`botst4rz`](https://github.com/Bintang73/botst4rz)
* [`ibnusyawall`](https://github.com/ibnusyawall)
## DONASI
* [`Saweria`](https://saweria.com/aditiaalfians)
